package com.example.pruebatecnica.Model;

import java.awt.print.Pageable;
import java.util.List;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author josva
 */

@Repository
public interface UsuarioRepositorio extends CrudRepository<Usuario, Integer> {
    @Query("select * from Usuario u where u.nombre like CONCAT ('%',:categoryName,'%')")
    public Iterable<Usuario> findByCategory(@Param("categoryName") String categoryName);
    
    
}
