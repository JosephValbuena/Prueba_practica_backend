package com.example.pruebatecnica.Model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.*;

/**
 *
 * @author josva
 */

@Table("usuario")
public class Usuario {
    @Id
    @Column("id_usuario")
    private int id;
    
    @Column("id_rol")
    private int rol;
    
    @Column("nombre")
    private String nombre;
    
    @Column("activo")
    private String activo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRol() {
        return rol;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getActivo() {
        return activo;
    }

    public void setActivo(String activo) {
        this.activo = activo;
    }
    
    
}
