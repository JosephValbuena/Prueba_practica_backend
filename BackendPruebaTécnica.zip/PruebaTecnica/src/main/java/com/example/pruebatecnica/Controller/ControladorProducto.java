package com.example.pruebatecnica.Controller;

import com.example.pruebatecnica.Model.Usuario;
import com.example.pruebatecnica.Model.UsuarioRepositorio;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author josva
 */

@RestController
@RequestMapping("/prueba")
@CrossOrigin
public class ControladorProducto {
    
    @Autowired
    UsuarioRepositorio repositorio;
    
    @GetMapping("/usuarios")
    public List<Usuario> getUsuarios(){
        List<Usuario> listaUsuarios = (List<Usuario>) repositorio.findAll();
        return listaUsuarios;
    }
    
    @GetMapping("/usuario/{id}")
    public Optional<Usuario> getUserById(@PathVariable int id){
        return repositorio.findById(id);
    }
    
    @PostMapping
    public Usuario agregar(@RequestBody Usuario u){
        return repositorio.save(u);
    }
    
    @PutMapping("/actualizar/{id}")
    public Usuario actualizarUsuario(@PathVariable int id, @RequestBody Usuario user){
        Usuario uActualizar = repositorio.findById(id).get();
        uActualizar.setRol(user.getRol());
        uActualizar.setNombre(user.getNombre());
        uActualizar.setActivo(user.getActivo());
        return repositorio.save(uActualizar);
    }
    
    @DeleteMapping("/eliminar/{id}")
    public void eliminarUsuario(@PathVariable int id){
        repositorio.deleteById(id);
    }
    
}
